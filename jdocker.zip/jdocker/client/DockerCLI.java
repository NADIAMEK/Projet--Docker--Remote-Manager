package com.jdocker.client;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class DockerCLI {
    public static void main(String[] args) {
        System.out.println("🐳 J-Docker Client");
        System.out.println("===================\n");

        String serverAddress = "192.168.1.3";  // IP de ton serveur
        int serverPort = 5000;

        try (
                Socket socket = new Socket(serverAddress, serverPort);
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(socket.getInputStream())
                );
                PrintWriter out = new PrintWriter(
                        socket.getOutputStream(), true
                );
                Scanner scanner = new Scanner(System.in)
        ) {
            System.out.println("✅ Connecté au serveur " + serverAddress + ":" + serverPort);

            // Lire le message de bienvenue
            System.out.println("\n" + in.readLine());

            // Boucle principale
            while (true) {
                System.out.print("\njdocker> ");
                String input = scanner.nextLine().trim();

                if (input.isEmpty()) continue;

                if (input.equalsIgnoreCase("exit") || input.equalsIgnoreCase("quit")) {
                    out.println("{\"command\":\"exit\"}");
                    System.out.println("👋 Au revoir!");
                    break;
                }

                // Préparer la commande JSON
                String[] parts = input.split("\\s+");
                String command = parts[0];

                // Construire le JSON manuellement
                StringBuilder json = new StringBuilder();
                json.append("{\"command\":\"").append(command).append("\"");

                if (parts.length > 1) {
                    json.append(",\"args\":[");
                    for (int i = 1; i < parts.length; i++) {
                        json.append("\"").append(parts[i]).append("\"");
                        if (i < parts.length - 1) json.append(",");
                    }
                    json.append("]");
                }
                json.append("}");

                // Envoyer la commande
                out.println(json.toString());

                // Lire et afficher la réponse
                String response = in.readLine();
                System.out.println(formatResponse(response));
            }

        } catch (Exception e) {
            System.out.println("❌ Erreur: " + e.getMessage());
        }
    }

    private static String formatResponse(String json) {
        if (json == null) return "⚠️ Pas de réponse";

        try {
            // Extraire le message du JSON
            if (json.contains("\"message\":")) {
                int start = json.indexOf("\"message\":\"") + 11;
                int end = json.indexOf("\",\"data\"");
                if (end == -1) end = json.indexOf("\"}", start);

                if (start > 10 && end > start) {
                    String message = json.substring(start, end);
                    message = message.replace("\\n", "\n").replace("\\\"", "\"");

                    // Ajouter emoji selon le statut
                    if (json.contains("\"status\":\"SUCCESS\"")) {
                        return "✅ " + message;
                    } else if (json.contains("\"status\":\"ERROR\"")) {
                        return "❌ " + message;
                    } else {
                        return "📨 " + message;
                    }
                }
            }

            return json; // Retourner tel quel si on ne peut pas parser

        } catch (Exception e) {
            return json;
        }
    }
}