package com.jdocker.server;

import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class DockerServer {
    private static final int PORT = 5000;
    private ServerSocket serverSocket;
    private ExecutorService threadPool;
    private volatile boolean running;

    public DockerServer() {
        this.threadPool = Executors.newCachedThreadPool();
        this.running = true;
    }

    public void start() {
        try {
            serverSocket = new ServerSocket(PORT);
            System.out.println("╔══════════════════════════════════════════╗");
            System.out.println("║     J-DOCKER SERVER v1.0                ║");
            System.out.println("║     Port: " + PORT + "                          ║");
            System.out.println("╚══════════════════════════════════════════╝");
            System.out.println("✅ Serveur démarré sur le port " + PORT);
            System.out.println("📡 En attente de connexions...\n");

            while (running) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("🔗 Nouveau client: " +
                        clientSocket.getInetAddress().getHostAddress());

                ClientHandler handler = new ClientHandler(clientSocket);
                threadPool.execute(handler);
            }

        } catch (IOException e) {
            if (running) {
                System.err.println("❌ Erreur serveur: " + e.getMessage());
            }
        }
    }

    public void stop() {
        running = false;
        threadPool.shutdown();
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("🛑 Serveur arrêté");
    }

    public static void main(String[] args) {
        DockerServer server = new DockerServer();

        // Gestion de Ctrl+C
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("\n🔴 Arrêt du serveur...");
            server.stop();
        }));

        server.start();
    }
}