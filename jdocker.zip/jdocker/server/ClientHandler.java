package com.jdocker.server;

import com.jdocker.models.Request;
import com.jdocker.models.Response;
import com.jdocker.utils.JsonUtil;

import java.io.*;
import java.net.*;

public class ClientHandler implements Runnable {
    private Socket clientSocket;
    private DockerService dockerService;

    public ClientHandler(Socket socket) {
        this.clientSocket = socket;
        this.dockerService = new DockerService();
    }

    @Override
    public void run() {
        String clientIP = clientSocket.getInetAddress().getHostAddress();
        System.out.println("👤 Client connecté: " + clientIP);

        try (
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(clientSocket.getInputStream())
                );
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
        ) {
            // Envoyer un message de bienvenue
            Response welcome = Response.success(
                    "🐳 J-Docker Remote Manager\n" +
                            "───────────────────────────────\n" +
                            "Format: {\"command\":\"xxx\",\"args\":[\"arg1\",\"arg2\"]}\n" +
                            "Tapez 'exit' pour quitter"
            );
            out.println(JsonUtil.toJson(welcome));

            String jsonRequest;
            while ((jsonRequest = in.readLine()) != null) {
                System.out.println("📨 [" + clientIP + "] → " + jsonRequest);

                // Si client veut quitter
                if (jsonRequest.equalsIgnoreCase("exit") ||
                        jsonRequest.equalsIgnoreCase("quit")) {
                    out.println(JsonUtil.toJson(Response.success("👋 Au revoir!")));
                    break;
                }

                try {
                    // Parser la requête JSON
                    Request request = JsonUtil.fromJson(jsonRequest, Request.class);

                    if (request == null) {
                        // Essayer comme commande texte simple (rétro-compatibilité)
                        request = parseSimpleCommand(jsonRequest);
                    }

                    // Traiter la requête
                    Response response = dockerService.processRequest(request);

                    // Envoyer la réponse JSON
                    String jsonResponse = JsonUtil.toJson(response);
                    out.println(jsonResponse);
                    System.out.println("📤 [" + clientIP + "] ← " + jsonResponse);

                } catch (Exception e) {
                    Response error = Response.error("❌ Erreur traitement: " + e.getMessage());
                    out.println(JsonUtil.toJson(error));
                }
            }

        } catch (IOException e) {
            System.out.println("⚠️ Client " + clientIP + " déconnecté: " + e.getMessage());
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println("🔚 Client " + clientIP + " déconnecté");
        }
    }

    /**
     * Pour compatibilité avec les clients qui envoient du texte simple
     */
    private Request parseSimpleCommand(String textCommand) {
        if (textCommand == null || textCommand.trim().isEmpty()) {
            return new Request("", new String[0]);
        }

        String[] parts = textCommand.trim().split("\\s+");
        String command = parts[0];

        String[] args = new String[parts.length - 1];
        if (args.length > 0) {
            System.arraycopy(parts, 1, args, 0, args.length);
        }

        return new Request(command, args);
    }
}