package com.jdocker.server;

import com.jdocker.models.Request;
import com.jdocker.models.Response;

public class DockerService {
    private DockerManager dockerManager;

    public DockerService() {
        this.dockerManager = new DockerManager();
        System.out.println("✅ DockerService initialisé");
    }

    /**
     * Traite une requête et retourne une réponse
     */
    public Response processRequest(Request request) {
        if (request == null || request.getCommand() == null) {
            return Response.error("Requête invalide");
        }

        String command = request.getCommand().toLowerCase();
        String[] args = request.getArgs() != null ? request.getArgs() : new String[0];

        try {
            switch (command) {
                case "ping":
                    return Response.success("pong 🏓");

                case "version":
                    return Response.success("Version Docker", dockerManager.getVersion());

                case "images":
                    return Response.success("Liste des images", dockerManager.listImages());

                case "containers":
                case "ps":
                    return Response.success("Liste des conteneurs", dockerManager.listContainers());

                case "status":
                    return dockerManager.isConnected()
                            ? Response.success("✅ Connecté à Docker")
                            : Response.error("❌ Non connecté à Docker");

                case "bonjour":
                case "hello":
                    return Response.success("👋 Bonjour ! Docker Manager est prêt.");

                // ============ NOUVELLES COMMANDES ============
                case "run":
                    if (args.length < 1) {
                        return Response.error("❌ Usage: run <image> [--name <nom>]");
                    }

                    String imageName = args[0];
                    String containerName = "";

                    // Gérer l'option --name
                    if (args.length >= 3 && args[1].equals("--name")) {
                        containerName = args[2];
                    } else if (args.length >= 2) {
                        containerName = args[1]; // Nom sans --name
                    }

                    String runResult = dockerManager.runContainer(imageName, containerName);
                    return Response.success(runResult);

                case "stop":
                    if (args.length < 1) {
                        return Response.error("❌ Usage: stop <container_id>");
                    }
                    return Response.success(dockerManager.stopContainer(args[0]));

                case "rm":
                    if (args.length < 1) {
                        return Response.error("❌ Usage: rm <container_id>");
                    }
                    return Response.success(dockerManager.removeContainer(args[0]));

                case "pull":
                    if (args.length < 1) {
                        return Response.error("❌ Usage: pull <image:tag>");
                    }
                    return Response.success(dockerManager.pullImage(args[0]));

                // =============================================

                default:
                    return Response.error("❌ Commande inconnue: '" + command + "'");
            }

        } catch (Exception e) {
            return Response.error("❌ Erreur interne: " + e.getMessage());
        }
    }

    public DockerManager getDockerManager() {
        return dockerManager;
    }
}