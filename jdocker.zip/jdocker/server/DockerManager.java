package com.jdocker.server;

import com.github.dockerjava.api.DockerClient;
import com.github.dockerjava.core.DefaultDockerClientConfig;
import com.github.dockerjava.core.DockerClientBuilder;
import com.github.dockerjava.api.model.Image;
import com.github.dockerjava.api.model.Container;

import java.util.List;

public class DockerManager {
    private DockerClient docker;
    private boolean isConnected = false;

    public DockerManager() {
        System.out.println("🔗 Connexion à Docker...");

        try {
            // REMPLACE AVEC L'IP DE TA VM
            String dockerHost = "tcp://192.168.10.144:2375";

            DefaultDockerClientConfig config = DefaultDockerClientConfig
                    .createDefaultConfigBuilder()
                    .withDockerHost(dockerHost)
                    .build();

            this.docker = DockerClientBuilder.getInstance(config).build();

            // Test de connexion
            String version = docker.versionCmd().exec().getVersion();
            this.isConnected = true;
            System.out.println("✅ Connecté à Docker v" + version);

        } catch (Exception e) {
            System.err.println("❌ ERREUR connexion Docker : " + e.getMessage());
            this.isConnected = false;
        }
    }

    public String getVersion() {
        if (!isConnected || docker == null) {
            return "❌ Docker non connecté";
        }

        try {
            com.github.dockerjava.api.model.Version version = docker.versionCmd().exec();

            StringBuilder result = new StringBuilder();
            result.append("🐳 Docker ").append(version.getVersion()).append("\n");
            result.append("📊 API: ").append(version.getApiVersion()).append("\n");

            if (version.getArch() != null) {
                result.append("🏗️  Arch: ").append(version.getArch()).append("\n");
            }

            if (version.getKernelVersion() != null) {
                result.append("🐧 Kernel: ").append(version.getKernelVersion()).append("\n");
            }

            if (version.getGoVersion() != null) {
                result.append("⚙️  Go: ").append(version.getGoVersion()).append("\n");
            }

            return result.toString();

        } catch (Exception e) {
            return "❌ Erreur: " + e.getMessage();
        }
    }

    public String listImages() {
        if (!isConnected || docker == null) {
            return "❌ Docker non connecté";
        }

        try {
            List<Image> images = docker.listImagesCmd().exec();
            StringBuilder result = new StringBuilder();

            if (images.isEmpty()) {
                return "📭 Aucune image Docker";
            }

            result.append("📦 ").append(images.size()).append(" images Docker:\n");
            result.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
            result.append(String.format("%-4s %-40s %-20s %-12s %-10s\n",
                    "No.", "REPOSITORY:TAG", "ID", "TAILLE", "CREATED"));
            result.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");

            int count = 1;
            for (Image image : images) {
                String[] tags = image.getRepoTags();
                String tag = (tags != null && tags.length > 0) ? tags[0] : "<none>:<none>";
                String id = image.getId().length() > 12 ? image.getId().substring(7, 19) : image.getId();
                String size = formatSize(image.getSize());

                // Formatage pour éviter les lignes trop longues
                String displayTag = tag;
                if (displayTag.length() > 40) {
                    displayTag = displayTag.substring(0, 37) + "...";
                }

                result.append(String.format("%-4d %-40s %-20s %-12s %-10s\n",
                        count, displayTag, id, size, "✓"));
                count++;
            }

            result.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
            result.append("ℹ️  Utilisez 'pull <image:tag>' pour télécharger une nouvelle image");

            return result.toString();
        } catch (Exception e) {
            return "❌ Erreur: " + e.getMessage();
        }
    }

    /**
     * Formate une taille en octets en format lisible (KB, MB, GB)
     */
    private String formatSize(long bytes) {
        if (bytes < 0) return "N/A";

        final String[] units = {"B", "KB", "MB", "GB", "TB"};
        int unitIndex = 0;
        double size = bytes;

        while (size >= 1024 && unitIndex < units.length - 1) {
            size /= 1024;
            unitIndex++;
        }

        return String.format("%.1f %s", size, units[unitIndex]);
    }

    public String listContainers() {
        if (!isConnected || docker == null) {
            return "❌ Docker non connecté";
        }

        try {
            List<Container> containers = docker.listContainersCmd()
                    .withShowAll(true)
                    .exec();

            StringBuilder result = new StringBuilder();

            if (containers.isEmpty()) {
                return "📭 Aucun conteneur Docker";
            }

            result.append("🐳 ").append(containers.size()).append(" conteneurs:\n");
            result.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
            result.append(String.format("%-15s %-25s %-20s %-12s %s\n",
                    "ID", "NOM", "IMAGE", "STATUT", "PORTS"));
            result.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");

            for (Container container : containers) {
                String name = container.getNames()[0].replace("/", "");
                String id = container.getId().substring(0, 12);
                String status = container.getStatus();
                String image = container.getImage();
                String state = status.contains("Up") ? "🟢 RUNNING" : "🔴 STOPPED";
                String ports = container.getPorts() != null ?
                        String.valueOf(container.getPorts().length) : "0";

                // Tronquer les noms trop longs
                if (name.length() > 25) {
                    name = name.substring(0, 22) + "...";
                }

                // Tronquer les images trop longues
                if (image.length() > 20) {
                    image = image.substring(0, 17) + "...";
                }

                result.append(String.format("%-15s %-25s %-20s %-12s %s\n",
                        id, name, image, state, ports + " port(s)"));
            }

            result.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
            result.append("ℹ️  Utilisez 'run <image>' pour créer un conteneur");

            return result.toString();
        } catch (Exception e) {
            return "❌ Erreur: " + e.getMessage();
        }
    }

    // ============= COMMANDES DE GESTION =============

    public String runContainer(String imageName, String containerName) {
        if (!isConnected || docker == null) {
            return "❌ Docker non connecté";
        }

        try {
            // Si aucun nom n'est fourni, générer un nom
            if (containerName == null || containerName.isEmpty()) {
                containerName = "container-" + System.currentTimeMillis();
            }

            System.out.println("▶️  Lancement conteneur: " + containerName + " avec " + imageName);

            // Créer le conteneur
            String containerId = docker.createContainerCmd(imageName)
                    .withName(containerName)
                    .exec()
                    .getId();

            // Démarrer le conteneur
            docker.startContainerCmd(containerId).exec();

            return String.format("✅ Conteneur créé et démarré:\n" +
                            "   ID: %s\n" +
                            "   Nom: %s\n" +
                            "   Image: %s\n" +
                            "   Status: 🟢 RUNNING",
                    containerId.substring(0, 12),
                    containerName,
                    imageName);

        } catch (Exception e) {
            return "❌ Erreur création conteneur: " + e.getMessage();
        }
    }

    public String stopContainer(String containerId) {
        if (!isConnected || docker == null) {
            return "❌ Docker non connecté";
        }

        try {
            System.out.println("⏸️  Arrêt conteneur: " + containerId);

            docker.stopContainerCmd(containerId).exec();

            return "✅ Conteneur " + containerId + " arrêté";

        } catch (Exception e) {
            return "❌ Erreur arrêt conteneur: " + e.getMessage();
        }
    }

    public String removeContainer(String containerId) {
        if (!isConnected || docker == null) {
            return "❌ Docker non connecté";
        }

        try {
            System.out.println("🗑️  Suppression conteneur: " + containerId);

            docker.removeContainerCmd(containerId).exec();

            return "✅ Conteneur " + containerId + " supprimé";

        } catch (Exception e) {
            return "❌ Erreur suppression conteneur: " + e.getMessage();
        }
    }

    public String pullImage(String imageName) {
        if (!isConnected || docker == null) {
            return "❌ Docker non connecté";
        }

        try {
            System.out.println("⬇️  Téléchargement image: " + imageName);

            // Version simple (sans progression)
            docker.pullImageCmd(imageName)
                    .start()
                    .awaitCompletion();

            return "✅ Image " + imageName + " téléchargée avec succès";

        } catch (Exception e) {
            return "❌ Erreur téléchargement: " + e.getMessage();
        }
    }

    public boolean isConnected() {
        return isConnected;
    }
}