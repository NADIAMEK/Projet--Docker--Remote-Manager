package com.jdocker.models;

public class Response {
    private String status;  // SUCCESS, ERROR, WARNING
    private String message;
    private Object data;

    // Constructeurs
    public Response() {}

    public Response(String status, String message) {
        this.status = status;
        this.message = message;
    }

    public Response(String status, String message, Object data) {
        this.status = status;
        this.message = message;
        this.data = data;
    }

    // Getters et Setters
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    // Méthodes utilitaires
    public static Response success(String message) {
        return new Response("SUCCESS", message);
    }

    public static Response success(String message, Object data) {
        return new Response("SUCCESS", message, data);
    }

    public static Response error(String message) {
        return new Response("ERROR", message);
    }

    public static Response warning(String message) {
        return new Response("WARNING", message);
    }
}