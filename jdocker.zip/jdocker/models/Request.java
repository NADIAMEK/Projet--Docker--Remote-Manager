package com.jdocker.models;

public class Request {
    private String command;
    private String[] args;

    // Constructeurs
    public Request() {}

    public Request(String command, String[] args) {
        this.command = command;
        this.args = args;
    }

    // Getters et Setters
    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public String[] getArgs() {
        return args;
    }

    public void setArgs(String[] args) {
        this.args = args;
    }

    // Méthode utilitaire
    public boolean hasArgs() {
        return args != null && args.length > 0;
    }
}