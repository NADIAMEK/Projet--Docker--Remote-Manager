package com.jdocker.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonProcessingException;

public class JsonUtil {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Convertit un objet Java en JSON
     */
    public static String toJson(Object object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            System.err.println("❌ Erreur conversion JSON: " + e.getMessage());
            return "{\"status\":\"ERROR\",\"message\":\"Erreur conversion JSON\"}";
        }
    }

    /**
     * Convertit une chaîne JSON en objet Java
     */
    public static <T> T fromJson(String json, Class<T> clazz) {
        try {
            return objectMapper.readValue(json, clazz);
        } catch (JsonProcessingException e) {
            System.err.println("❌ Erreur parsing JSON: " + e.getMessage());
            return null;
        }
    }

    /**
     * Formate joliment un JSON
     */
    public static String prettyPrint(Object object) {
        try {
            return objectMapper.writerWithDefaultPrettyPrinter()
                    .writeValueAsString(object);
        } catch (Exception e) {
            return toJson(object);
        }
    }
}